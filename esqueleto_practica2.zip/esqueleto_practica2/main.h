#ifndef __MAIN_H__
#define __MAIN_H__

#include <world.h>
//#ifdef PATHTRACER_EXPORTS
//#define PATHTRACER_API __declspec(dllexport) __stdcall
//#else
//#define PATHTRACER_API __declspec(dllimport)
//#endif


//void PATHTRACER_API renderSceneFromFile(float*& image, float*& alpha, World*& world, const char* filename);

//void PATHTRACER_API WriteImg(const char* name, float *pixels, float *alpha, int xRes,
//    int yRes, int totalXRes, int totalYRes, int xOffset, int yOffset);

#endif // __MAIN_H__
